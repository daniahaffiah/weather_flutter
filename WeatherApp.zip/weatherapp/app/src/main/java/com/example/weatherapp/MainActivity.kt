package com.example.weatherapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.weatherapp.ui.theme.WeatherAppTheme

<?xml version="1.0" encoding="utf-8"?>
<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
xmlns:tools="http://schemas.android.com/tools"
android:layout_width="match_parent"
android:layout_height="match_parent"
android:padding="16dp"
tools:context=".MainActivity">

<TextView
android:id="@+id/tv_city_name"
android:layout_width="wrap_content"
android:layout_height="wrap_content"
android:text="City Name"
android:textSize="24sp"
android:textStyle="bold"
android:layout_centerHorizontal="true"/>

<ImageView
android:id="@+id/img_weather_icon"
android:layout_width="100dp"
android:layout_height="100dp"
android:layout_below="@id/tv_city_name"
android:layout_centerHorizontal="true"
android:layout_marginTop="8dp"/>

<TextView
android:id="@+id/tv_temperature"
android:layout_width="wrap_content"
android:layout_height="wrap_content"
android:text="25°C"
android:textSize="48sp"
android:layout_below="@id/img_weather_icon"
android:layout_centerHorizontal="true"
android:layout_marginTop="16dp"/>

<TextView
android:id="@+id/tv_weather_description"
android:layout_width="wrap_content"
android:layout_height="wrap_content"
android:text="Sunny"
android:textSize="18sp"
android:layout_below="@id/tv_temperature"
android:layout_centerHorizontal="true"
android:layout_marginTop="8dp"/>

<Button
android:id="@+id/btn_refresh"
android:layout_width="wrap_content"
android:layout_height="wrap_content"
android:text="Refresh"
android:layout_below="@id/tv_weather_description"
android:layout_centerHorizontal="true"
android:layout_marginTop="16dp"/>

</RelativeLayout>
